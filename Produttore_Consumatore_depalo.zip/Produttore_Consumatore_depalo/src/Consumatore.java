
/*• Consumatore: deve consumare i numeri generati dal Produttore e ogni volta che li
consuma stampa il numero letto e stampa una statistica dei numeri pari e dei numeri
dispari letti
*/

public class Consumatore implements Runnable {

	Buffer buffer;
	
	public Consumatore (Buffer buffer) {
		this.buffer = buffer;
	}
	
	public void run() {
		
		int conta_pari = 0;
		int conta_dispari=0;
		int b_g;
		
		while (true) {
			b_g = buffer.get();
			if (b_g % 2 == 0) {
				conta_pari++;
			} else {
				conta_dispari++;
			}
		
			System.out.println("numero consumato: " + b_g);
			System.out.println("i numeri pari consumati fino ad ora sono: " + conta_pari);
			System.out.println("i numeri dispari consumati fino ad ora sono: " + conta_dispari);
		}
	}
	
}
