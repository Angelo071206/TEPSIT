/*
• Produttore: genera all’infinito un numero casuale tra 0 e 1023 ogni Xms, dove X è un
numero casuale tra 100 e 1000.
*/

import java.util.Random;

public class Produttore implements Runnable {

	Buffer buffer;
	
	public Produttore (Buffer buffer) {
		this.buffer = buffer;
	}
	
	public void run() {
		
		int X;		//valore casuale che corrisponde al tempo
		Random random = new Random();
		
		while(true) {
			try {
				
				X=(random.nextInt(1000)) + 100;
				Thread.sleep(X);
				
			} catch (InterruptedException e) {
				
			}
			
			buffer.add(random.nextInt(1024));
			
			}
	}


}

