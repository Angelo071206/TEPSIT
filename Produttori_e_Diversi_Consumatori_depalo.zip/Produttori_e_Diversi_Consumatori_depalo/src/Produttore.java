/*
• Produttore: genera all’infinito un numero casuale R tra -1024 e 1023 e attende 
R/100*50ms se positivo, altrimenti 200ms
*/

import java.util.Random;

public class Produttore implements Runnable {

	Buffer buffer;
	
	public Produttore (Buffer buffer) {
		this.buffer = buffer;
	}
	
	public void run() {
		
		int R;		//valore casuale che corrisponde al tempo
		Random random = new Random();
		
		while(true) {
			
			R = (random.nextInt(2048) - 1024);
			buffer.add(R);
			
			if ( R > 0 ) {
				try {
					Thread.sleep(R / 100 * 50);
				} catch (InterruptedException e) {
				
				}
			}else {
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
				
				}
			}
			
		}
	}


}

