/*
Fare un programma che crea un Produttore ed un valore C di Consumatore con il seguente 
ruolo:
• Produttore: genera all’infinito un numero casuale R tra -1024 e 1023 e attende 
R/100*50ms se positivo, altrimenti 200ms
• Consumatore: ogni consumatore deve contare i numeri negativi e calcolare la media 
degli ultimi 5 valori positivi. Ogni volta che consuma un valore stampa la statistica 
aggiornata e poi aspetta 100ms
Il programma deve garantire che i dati prodotti vengo consumati in ordine FIFO e che non vi 
devono essere perdite dei dati prodotti dal Consumatore e ogni dato può essere consumato da 
un solo Consumatore.
Progettare il sistema in modo da MASSIMIZZARE la scalabilità, cioè fare in modo che più 
Consumatori possono “accedere contemporaneamente” al Buffer
*/

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int size = 10;
		int C;
		
		System.out.println("Quanti consumatori vuoi creare? ");
		C = scanner.nextInt();
		Thread[] thread = new Thread[C];
		
		Buffer buffer = new Buffer(size);
		Produttore produttore = new Produttore(buffer);
		
		Thread thread_p = new Thread(produttore);
		
		for ( int i = 0; i < C; i++) {
			Consumatore consumatore = new Consumatore(buffer);
			thread[i] = new Thread (consumatore);
		}
		
		thread_p.start();
		for ( int i = 0; i < C; i++) {
			thread[i].start();
		}
	}

}