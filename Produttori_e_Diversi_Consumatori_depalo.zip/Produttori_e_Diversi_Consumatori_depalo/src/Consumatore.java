
/*
 • Consumatore: ogni consumatore deve contare i numeri negativi e calcolare la media 
degli ultimi 5 valori positivi. Ogni volta che consuma un valore stampa la statistica 
aggiornata e poi aspetta 100ms
*/

public class Consumatore implements Runnable {

	Buffer buffer;
	
	public Consumatore (Buffer buffer) {
		this.buffer = buffer;
	}
	
	public void run() {
		
		int conta_negativi=0;
		int b_g;
		int media_n_positivi = 0;
		int conta_n_positivi = 0;
		int somma_n_positivi = 0;
		int attesa = 100;
		
		while (true) {
			b_g = buffer.get();
			if (b_g > 0) {
				conta_n_positivi ++;
				somma_n_positivi += b_g;
				if ( conta_n_positivi ==  5 ) {
					media_n_positivi= somma_n_positivi / conta_n_positivi;
					somma_n_positivi = 0;
					conta_n_positivi = 0;
				}
				
			} else {
				conta_negativi++;
			}
		
			System.out.println("(" +Thread.currentThread().threadId() + ")" + "numero consumato: " + b_g);
			System.out.println("Media numeri positivi aggiornata ogni 5 numeri positivi: " + media_n_positivi);
			System.out.println("i numeri negativi consumati fino ad ora sono: " + conta_negativi);
			
			try {
				Thread.sleep(attesa);
			} catch (InterruptedException e) {
				
			}
		}
	}
	
}
