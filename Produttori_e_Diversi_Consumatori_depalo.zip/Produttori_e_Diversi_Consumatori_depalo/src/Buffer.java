import java.util.LinkedList;
import java.util.Queue;

public class Buffer {

	Queue <Integer> coda;
	int size;
	
	public Buffer(int size) {
		coda = new LinkedList();
		this.size = size;
	}

	
	public synchronized void add(int D) {
		
		while (true) {
			if(coda.size() < size) {
				coda.add(D);
				this.notifyAll();
				return;
			} else {
				try {
					this.wait();
				} catch (InterruptedException e) {
					
				}
			}
		}
	}
	
	public synchronized int get() {
		
		int numero_coda; 
		
		while (true) {
			if (coda.size() == 0) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					
				}
			}
			else {
				numero_coda = coda.remove();
				this.notifyAll();
				return numero_coda;
			}
		}
	}
}