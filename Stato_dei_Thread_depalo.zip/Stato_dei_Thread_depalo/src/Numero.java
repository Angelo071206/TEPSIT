
public class Numero {

	private int numero = 0;
	
	public synchronized void incrementa() {
		numero++;
	}
	
	public synchronized int get() {
		return numero;
	}
}
