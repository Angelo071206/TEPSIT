/*
Fare un programma che chiede all’utente due valori T ed N, dove T indica quanti Thread creare 
ed ogni Thread conta i valori (SENZA STAMPARE) da 0 fino ad X dove X è un numero compreso 
tra 0 e N.
Ogni Thread dopo che ha stampato un valore aspetta 120ms
Il Thread principale stampa periodicamente (al massimo una volta al secondo) lo stato dei 
Thread e per i Thread attivi stampa il valore a cui è arrivato a contare, mentre per quelli terminati 
stampa “COMPLETATO”, quando tutti i Thread hanno raggiunto il loro valore X il programma 
deve stampare “TUTTI I THREAD COMPLETATI” e terminare
*/

import java.util.Random;
import java.util.Scanner;


public class main {

	public static void main(String[] args) {
		
		int T;					//numero di Thread da creare
		int N;					//numero che i thread devono contare
		int X;					//numero tra 0 e N
		int D=500;				//tempo con il quale il thread principale stampa lo stato dei thread
		int t_conta=120;		//tempo che impiega un thread per contare
		boolean alive = false;	//per vedere lo stato del Thread
		Numero numero = new Numero();
		
		Scanner scanner = new Scanner(System.in);
		
		Random numerocasuale = new Random();
		
		//chiedo quanti Thread creare e creo un Array per gestirli
		System.out.println("Quanti Thread vuoi creare? ");	
		T = scanner.nextInt();
		Thread[] thread = new Thread[T];
		
		System.out.println("Fino a quanto deve contare un Thread? ");	
		N = scanner.nextInt();
		
		
		
		for (int i = 0; i<T; i++) {
			
			//X è un valore casuale compreso tra 0 e N
			X = numerocasuale.nextInt(N);
			
			Contatore contatore = new Contatore(X,t_conta,numero);
			thread[i] = new Thread(new Contatore(X,t_conta,numero));
		}
		
		for (int i = 0; i<T; i++) {
			thread[i].start();
		}
		
		do {
			alive = false;
			
			try {
				
				Thread.sleep(D);
			
			} catch (InterruptedException e) {
				
				System.out.println("Interruzione Thread");
				
			}
			
			for (int i = 0; i < T; i++) {
				if ( thread[i].isAlive() == false) {
					System.out.println("COMPLETATO");
				} else {
				System.out.println (numero.get());
					alive = true;
				}
			}
			
		} while (alive == true);
		
		System.out.println("TUTTI I THREAD COMPLETATI");
		
		
	}
}