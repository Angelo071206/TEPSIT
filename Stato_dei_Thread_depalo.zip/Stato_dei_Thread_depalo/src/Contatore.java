
public class Contatore implements Runnable{

	private int X;
	private int t_conta;
	private Numero numero;
	
	public Contatore(int X, int t_conta, Numero numero){
		this.X = X;
		this.t_conta = t_conta;
		this.numero=numero;
	}

	
	public void run() {
		
		String nome = Thread.currentThread().getName();
		long tid = Thread.currentThread().getId();
		String output = nome +"(" +tid+ ")" ;
		
		
		for (int i = 0; numero.get() < X; i++) {
			try {
				
				Thread.sleep(t_conta);
				
			} catch (InterruptedException e) {
				
				System.out.println("Interruzione Thread");
				
			}
			
			numero.incrementa();
		}
		
	}
}
