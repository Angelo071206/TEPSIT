import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Stack;

public class Buffer {

	Stack <Integer> pila;
	int size;
	
	public Buffer(int size) {
		pila = new Stack<Integer>();
		this.size = size;
	}

	
	public synchronized void add(int D) {
		
		while (true) {
			if(pila.size() < size) {
				pila.push(D);
				this.notifyAll();
				return;
			} else {
				try {
					this.wait();
				} catch (InterruptedException e) {
					
				}
			}
		}
	}
	
	public synchronized int get() {
		
		int numero_pila; 
		
		while (true) {
			if (pila.size() == 0) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					
				}
			}
			else {
				numero_pila = pila.pop();
				this.notifyAll();
				return numero_pila;
			}
		}
	}
}
