/*
• Produttore: genera all’infinito un numero casuale tra 0 e 1023 ogni Xms, dove X è un
numero casuale tra 100 e 1000.
• Consumatore: deve consumare i numeri generati dal Produttore e ogni volta che li
consuma stampa il numero letto e stampa una statistica dei numeri pari e dei numeri
dispari letti
Il programma deve garantire che i dati prodotti vengo consumati in ordine FIFO e che non vi
devono essere perdite dei dati prodotti dal Consumatore.

dati nel buffer con politica LIFO
*/

public class Main {

	public static void main(String[] args) {
		
		int size = 10;
		Buffer buffer = new Buffer(size);
		Produttore produttore = new Produttore(buffer);
		Consumatore consumatore = new Consumatore(buffer);
		
		Thread thread_p = new Thread(produttore);
		Thread thread_c = new Thread(consumatore);
		
		thread_p.start();
		thread_c.start();
	}

}
